import { Module } from '@nestjs/common';
import { ConnectionsModule } from '../../connections/connections.module';
import { ConnectorsModule } from '../../connectors/connectors.module';
import { ProviderRuntimeModule } from '../../provider-runtime/provider-runtime.module';
import { RealityPipelineModule } from '../../reality-pipeline/reality-pipeline.module';
import { GmailService } from './gmail.service';
import { GmailController } from './gmail.controller';
import { GoogleTransportModule } from '../google/google-transport.module';
@Module({ imports: [ConnectionsModule, ConnectorsModule, ProviderRuntimeModule, RealityPipelineModule, GoogleTransportModule], controllers: [GmailController],
  providers: [GmailService], exports: [GmailService] })
export class GmailModule {}
