import { Injectable, OnApplicationShutdown, OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Worker } from 'bullmq';
import IORedis from 'ioredis';
import { ExecutionRunner } from './execution-runner.service';
import { ExecutionLeaseService } from './execution-lease.service';
import { workerEnabled } from '../common/app-role';
import { ObservabilityService } from '../observability/observability.service';

const WORKER_ID = () => `execution-${process.pid}`;

@Injectable()
export class ExecutionWorker implements OnModuleInit, OnApplicationShutdown {
  private worker?: Worker<{ executionId: string }>;
  private redis?: IORedis;
  private readonly activeExecutions = new Set<string>();

  constructor(
    private readonly config: ConfigService,
    private readonly runner: ExecutionRunner,
    private readonly lease: ExecutionLeaseService,
    private readonly telemetry: ObservabilityService,
  ) {}

  onModuleInit() {
    if (process.env.NODE_ENV === 'test' || !workerEnabled('execution-worker')) return;
    this.redis = new IORedis(this.config.getOrThrow<string>('REDIS_URL'), { maxRetriesPerRequest: null });
    const prefix = this.config.get<string>('REDIS_KEY_PREFIX');
    this.worker = new Worker('lazy-armor-executions', async (job) => {
      const outcome = await this.processExecution(job.data.executionId);
      if (outcome.retryScheduled) throw new Error('CONTROLLED_RETRY_SCHEDULED');
      return outcome;
    }, { connection: this.redis, concurrency: 4, ...(prefix ? { prefix } : {}) });
  }

  async processExecution(executionId: string) {
    const workerId = WORKER_ID();
    if (this.activeExecutions.has(executionId)) {
      this.telemetry.event('warn', 'execution_worker_lease_skipped', { executionId, status: 'running', workerId });
      return { status: 'running' as const };
    }
    this.activeExecutions.add(executionId);
    let heartbeat: ReturnType<typeof setInterval> | undefined;
    try {
      const lease = await this.lease.acquire(executionId, workerId);
      if (!lease.acquired) {
        this.telemetry.event('warn', 'execution_worker_lease_skipped', { executionId, status: lease.status, workerId });
        return { status: lease.status };
      }
      heartbeat = setInterval(() => {
        void this.lease.heartbeat(executionId, lease.workerToken).catch(() => undefined);
      }, Math.max(100, Math.floor(this.lease.leaseDurationMs / 4)));
      return await this.telemetry.runWithContext({
        executionId,
        requestId: executionId,
        workerId,
        attempt: lease.recovered ? 2 : 1,
        takeover: lease.recovered,
      }, async () => {
        this.telemetry.event('log', 'execution_worker_started', { executionId, workerId, takeover: lease.recovered });
        const outcome = await this.runner.run(executionId, lease.workerToken, {
          workerId,
          attempt: lease.recovered ? 2 : 1,
          takeover: lease.recovered,
        });
        this.telemetry.event('log', 'execution_worker_finished', { executionId, workerId, status: outcome.status, takeover: lease.recovered });
        return outcome;
      });
    } finally {
      if (heartbeat) clearInterval(heartbeat);
      this.activeExecutions.delete(executionId);
    }
  }

  async readiness() {
    if (!this.worker) return { ready: false, reason: 'execution_worker_not_running' };
    await this.worker.waitUntilReady();
    return { ready: this.worker.isRunning(), reason: this.worker.isRunning() ? null : 'execution_worker_not_running' };
  }

  async onApplicationShutdown() {
    await this.worker?.close();
    if (this.redis && this.redis.status !== 'end') await this.redis.quit();
  }
}
