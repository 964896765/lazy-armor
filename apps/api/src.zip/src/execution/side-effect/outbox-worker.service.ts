import { Inject, Injectable, OnApplicationShutdown, OnModuleInit } from '@nestjs/common';
import { ConnectorError, ConnectorRegistry, resolveSideEffectContract, type SideEffectContract } from '@lazy-armor/connector-sdk';
import { executionSteps, executions, outboxMessages, plans, sideEffectOperations } from '@lazy-armor/database';
import { and, eq, or } from 'drizzle-orm';
import { DATABASE, type InjectedDatabase } from '../../common/database.module';
import { AuditService } from '../../audit/audit.service';
import { SnapshotSanitizer } from '../../common/snapshot-sanitizer.service';
import { NotificationService } from '../../notifications/notification.service';
import { ExecutionEventService } from '../execution-event.service';
import { ExecutionPolicyService } from '../execution-policy.service';
import { ExecutionResultResolver } from '../execution-result-resolver.service';
import { ExecutionStateService } from '../execution-state.service';
import { ExecutionStepStateService } from '../execution-step-state.service';
import { RuntimeConnectionGuard } from '../runtime-connection-guard.service';
import { asRuntimeError, ExecutionRuntimeError, EXECUTION_TERMINAL_STATES, type ExecutionStatus } from '../execution.types';
import { QueueService } from '../../infrastructure/queue.service';
import { workerEnabled } from '../../common/app-role';
import { OutboxService } from './outbox.service';
import { SideEffectOperationsService } from './side-effect-operations.service';
import { ObservabilityService } from '../../observability/observability.service';
import { UsageService } from '../../usage/usage.service';
import { ConnectorRateLimitCoordinator } from '../../infrastructure/connector-rate-limit-coordinator.service';
import { ProviderCircuitBreakerService } from '../../infrastructure/provider-circuit-breaker.service';
import { ActionAdapter } from '../action-adapter.service';
import { VerificationService } from '../verification.service';
import { TerminalHandoffGuard, type TerminalHandoffProof } from '../../strategy-runtime/terminal-handoff-guard.service';
import { requiresTerminalHandoffProof } from '@lazy-armor/plan-schema';

function handoffTargetContext(actionConfig: Record<string, unknown>): Record<string, unknown> {
  const handoff = actionConfig.handoffTarget;
  if (!handoff || typeof handoff !== 'object' || Array.isArray(handoff)) return {};
  const target = handoff as Record<string, unknown>;
  if (!target.action || typeof target.action !== 'object' || Array.isArray(target.action)) return {};
  return target.kind === 'NOTION_UPDATE' ? { notionAction: target.action }
    : target.kind === 'CALENDAR_EVENT' ? { calendarEvent: target.action } : {};
}

type TargetAuthorizationFence = { connectorKey: string; credentialRef: string | null; credentialVersion: number | null };

function targetAuthorizationFence(snapshot: Record<string, unknown>, required: boolean): TargetAuthorizationFence | null {
  const raw = snapshot.targetAuthorizationFence;
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
    if (required) throw new ExecutionRuntimeError('TERMINAL_HANDOFF_NOT_AUTHORIZED', 'Cross-provider action is missing its target authorization fence');
    return null;
  }
  const value = raw as Record<string, unknown>;
  const credentialRef = value.credentialRef;
  const credentialVersion = value.credentialVersion;
  if (typeof value.connectorKey !== 'string' || value.connectorKey.length === 0
    || !(credentialRef === null || typeof credentialRef === 'string')
    || !(credentialVersion === null || (typeof credentialVersion === 'number' && Number.isInteger(credentialVersion) && credentialVersion > 0))
    || ((credentialRef === null) !== (credentialVersion === null))) {
    throw new ExecutionRuntimeError('TERMINAL_HANDOFF_NOT_AUTHORIZED', 'Target authorization fence is invalid');
  }
  return { connectorKey: value.connectorKey, credentialRef, credentialVersion };
}

const MAX_OUTBOX_ATTEMPTS = 5;
const RETRY_MAX_MS = 10_000;
const POLL_INTERVAL_MS = 1_000;
const CLAIM_BATCH = 8;
const WORKER_ID = () => `outbox-${process.pid}`;
// 审批后仍不可覆盖的运行权限阻断码：直接受控失败，绝不无限重试。
const BLOCKING_CODES = new Set(['TERMINAL_HANDOFF_NOT_AUTHORIZED', 'CONNECTION_REVOKED', 'CONNECTION_EXPIRED', 'CONNECTION_UNAVAILABLE', 'CONNECTION_NOT_OWNED', 'CAPABILITY_NOT_FOUND', 'CAPABILITY_NOT_GRANTED', 'PERMISSION_REVOKED', 'PERMISSION_EXPIRED', 'CREDENTIAL_INVALID', 'CREDENTIAL_EXPIRED', 'ACTION_INTENT_MISSING', 'ACTION_ADAPTER_INTEGRITY_ERROR', 'ACTION_RESOLUTION_CHANGED', 'RISK_CONTEXT_CHANGED', 'RISK_SNAPSHOT_MISSING', 'APPROVAL_NOT_VALID', 'APPROVAL_EXPIRED']);

@Injectable()
export class OutboxWorker implements OnModuleInit, OnApplicationShutdown {
  private timer?: ReturnType<typeof setInterval>;
  constructor(
    @Inject(DATABASE) private readonly db: InjectedDatabase,
    private readonly outbox: OutboxService,
    private readonly operations: SideEffectOperationsService,
    private readonly registry: ConnectorRegistry,
    private readonly guard: RuntimeConnectionGuard,
    private readonly stepStates: ExecutionStepStateService,
    private readonly states: ExecutionStateService,
    private readonly resultResolver: ExecutionResultResolver,
    private readonly events: ExecutionEventService,
    private readonly audit: AuditService,
    private readonly notifications: NotificationService,
    private readonly sanitizer: SnapshotSanitizer,
    private readonly policy: ExecutionPolicyService,
    private readonly queue: QueueService,
    private readonly telemetry: ObservabilityService,
    private readonly usage: UsageService,
    private readonly rateLimits: ConnectorRateLimitCoordinator,
    private readonly circuits: ProviderCircuitBreakerService,
    private readonly actionAdapter: ActionAdapter,
    private readonly verification: VerificationService,
    private readonly terminalGuard: TerminalHandoffGuard,
  ) {}

  onModuleInit() {
    if (process.env.NODE_ENV === 'test' || !workerEnabled('outbox-worker')) return;
    this.timer = setInterval(() => void this.poll().catch(() => undefined), POLL_INTERVAL_MS);
    this.timer.unref();
  }
  onApplicationShutdown() { if (this.timer) clearInterval(this.timer); }

  readiness() { return { ready: Boolean(this.timer), reason: this.timer ? null : 'outbox_worker_not_running' }; }

  // §22：claim 由 FOR UPDATE SKIP LOCKED 保证多个 Worker 只有一个获得执行权。
  async poll() {
    const claimed = await this.outbox.claim(CLAIM_BATCH, WORKER_ID());
    this.telemetry.gauge('outbox.pending', claimed.length, { phase: 'claimed_batch' });
    let processed = 0;
    for (const message of claimed) {
      try {
        await this.process(message);
        processed += 1;
      } catch {
        // 单条失败不阻塞其余消息；lease 过期后会被重新 claim。
        await this.releaseForRecovery(message.id).catch(() => undefined);
      }
    }
    this.telemetry.event('log', 'outbox_poll_completed', { claimed: claimed.length, processed });
    return { claimed: claimed.length, processed };
  }

  private async releaseForRecovery(id: string) {
    await this.db.update(outboxMessages).set({ status: 'retry_wait', lockedBy: null, lockExpiresAt: null, nextAttemptAt: new Date(Date.now() + 1_000), updatedAt: new Date() }).where(eq(outboxMessages.id, id));
  }

  async process(message: typeof outboxMessages.$inferSelect) {
    const payload = message.payloadJson as { operationId: string; executionStepId: string; executionId: string; userId: string };
    const workerId = WORKER_ID();
    const attempt = message.attemptCount + 1;
    const redelivery = message.attemptCount > 0 || message.status === 'processing';
    return this.telemetry.runWithContext({
      correlationId: message.correlationId,
      requestId: payload.executionId,
      userId: message.userId,
      executionId: payload.executionId,
      executionStepId: payload.executionStepId,
      sideEffectOperationId: payload.operationId,
      workerId,
      attempt,
      redelivery,
    }, async () => {
      // §25：Dispatch 前重新校验 payload hash；被篡改的消息立即进入 Dead Letter，绝不出站。
      try {
        await this.outbox.assertPayloadIntegrity(message.id, payload);
      } catch (error) {
        const mapped = asRuntimeError(error);
        this.telemetry.increment('outbox.dead', 1, { reason: mapped.code });
        await this.outbox.markDead(message.id, mapped.code, this.sanitizer.sanitizeText(mapped));
        await this.audit.append({ actorType: 'outbox_worker', actorUserId: null, action: 'SIDE_EFFECT_PAYLOAD_INTEGRITY_FAILURE', resourceType: 'outbox_message', resourceId: message.id, userId: message.userId, executionId: payload.executionId, executionStepId: payload.executionStepId, outboxMessageId: message.id, correlationId: message.correlationId, causationId: payload.operationId, source: 'outbox_worker', result: 'blocked', reasonCode: mapped.code });
        return;
      }
      const operation = await this.operations.get(payload.operationId);
      if (!operation) {
        this.telemetry.increment('outbox.dead', 1, { reason: 'OPERATION_NOT_FOUND' });
        await this.outbox.markDead(message.id, 'OPERATION_NOT_FOUND', 'SideEffectOperation no longer exists');
        return;
      }
      // §23 Redelivery：Operation 已成功 → 不创建第二个业务动作，直接 published。
      if (operation.status === 'succeeded') {
        await this.outbox.markPublished(message.id);
        // §63 恢复：DB 已成功但 Execution 尚未 finalize（崩溃），Redelivery 需推进 Execution。
        const execRow = (await this.db.select({ status: executions.status }).from(executions).where(eq(executions.id, payload.executionId)).limit(1))[0];
        if (execRow && !EXECUTION_TERMINAL_STATES.has(execRow.status as ExecutionStatus)) {
          await this.resumeExecution(operation.userId, payload.executionId);
        }
        return;
      }
      // 终态不可重放。
      if (operation.status === 'outcome_unknown' || operation.status === 'cancelled' || operation.status === 'failed') {
        this.telemetry.increment('outbox.dead', 1, { reason: `OPERATION_${operation.status.toUpperCase()}` });
        await this.outbox.markDead(message.id, `OPERATION_${operation.status.toUpperCase()}`, 'Operation reached a terminal state that cannot be redelivered');
        return;
      }
      await this.dispatch(operation, message);
    });
  }

  private async dispatch(operation: typeof sideEffectOperations.$inferSelect, message: typeof outboxMessages.$inferSelect) {
    const payload = message.payloadJson as { operationId: string; executionStepId: string; executionId: string };
    let contract: SideEffectContract | null = null;
    let dispatchStarted = false;
    let connectorKeyForMetrics = 'unknown';
    const startedAt = Date.now();
    try {
      // §56：Plan 不再 active，不得派发外部副作用。
      const execution = (await this.db.select({ planId: executions.planId, cancellationRequestedAt: executions.cancellationRequestedAt, resolvedRiskSnapshotJson: executions.resolvedRiskSnapshotJson }).from(executions).where(eq(executions.id, payload.executionId)).limit(1))[0];
      const plan = execution ? (await this.db.select({ status: plans.status }).from(plans).where(and(eq(plans.id, execution.planId), eq(plans.userId, operation.userId))).limit(1))[0] : null;
      if (execution?.cancellationRequestedAt) {
        if (operation.status === 'executing') {
          await this.unknownOutcome(operation, message, new ExecutionRuntimeError('OUTCOME_UNKNOWN', 'Cancelled dispatch recovery cannot confirm the prior effect'), payload.executionId);
          return;
        }
        await this.cancelOperation(operation, message, 'CANCELLED_BEFORE_DISPATCH', payload.executionId);
        return;
      }
      if (!plan || plan.status !== 'active') {
        if (operation.status === 'executing') {
          await this.unknownOutcome(operation, message, new ExecutionRuntimeError('OUTCOME_UNKNOWN', 'Inactive plan dispatch recovery cannot confirm the prior effect'), payload.executionId);
          return;
        }
        await this.failOperation(operation, message, 'PLAN_NOT_ACTIVE', 'Plan is no longer active');
        return;
      }
      const rebuilt = await this.operations.rebuildRequest(operation.executionStepId);
      // Cross-provider handoffs keep the authenticated source Truth current until the target write boundary.
      const terminalProof = execution?.resolvedRiskSnapshotJson?.terminalHandoffProof as TerminalHandoffProof | undefined;
      const terminalAction = requiresTerminalHandoffProof(rebuilt.actionConfig);
      if (terminalAction && !terminalProof) {
        throw new ExecutionRuntimeError('TERMINAL_HANDOFF_NOT_AUTHORIZED', 'Cross-provider action is missing its server-owned Truth handoff proof');
      }
      if (terminalProof) await this.terminalGuard.assertExecutionCurrent(operation.userId, execution!.planId, terminalProof);
      // §17 Runtime Security Recheck：再次检查 Connection/Permission/Credential（Approval 永远不能覆盖 Permission）。
      let connectorKey: string;
      let credentialRef: string | null | undefined;
      let credentialVersion: number | null | undefined;
      let credentialExpiresAt: Date | null | undefined;
      if (operation.connectionId && operation.capabilityKey) {
        const expectedFence = targetAuthorizationFence(operation.requestSnapshotJson, terminalAction);
        const checked = await this.guard.assertUsable(operation.userId, operation.connectionId, operation.capabilityKey, expectedFence ?? undefined);
        connectorKey = checked.connectorKey;
        connectorKeyForMetrics = checked.connectorKey;
        credentialRef = checked.credentialRef;
        credentialVersion = checked.credentialVersion;
        credentialExpiresAt = checked.credentialExpiresAt;
      } else {
        throw new ExecutionRuntimeError('SAFETY_GATE_REQUIRES_IDEMPOTENCY', 'Side effect cannot be dispatched without a bound Connection and Capability');
      }
      // §42/§43：Side Effect Contract 解析；未知能力默认最保守。
      const capability = this.registry.capability(connectorKey, operation.capabilityKey);
      contract = capability ? resolveSideEffectContract(capability) : null;
      if (operation.status === 'executing' && contract?.retrySafety !== 'safe') {
        // A crashed/expired unsafe dispatch may already have committed at the provider. Recovery is lookup-only.
        await this.unknownOutcome(operation, message, new ExecutionRuntimeError('OUTCOME_UNKNOWN', 'Unsafe dispatch was interrupted after acquisition'), payload.executionId);
        return;
      }
      const connector = this.registry.get(connectorKey);
      await this.circuits.beforeRequest(connectorKey);
      await this.rateLimits.acquire({ provider: connectorKey, connectionId: operation.connectionId });
      await this.actionAdapter.assertOperation(operation.executionId, operation.executionStepId);
      await this.events.append(payload.executionId, 'side_effect_dispatch_started', { operationId: operation.id, attempt: operation.attemptCount + 1 }, operation.executionStepId);
      await this.stepStates.transition(operation.executionStepId, 'running', { dispatchStatus: 'executing' });
      if (contract?.retrySafety !== 'safe') {
        // Fence even overlapping workers before an unsafe external call. Only one prepared/retry_wait operation can acquire dispatch.
        const acquired = await this.db.update(sideEffectOperations).set({ status: 'executing', attemptCount: operation.attemptCount + 1,
          startedAt: operation.startedAt ?? new Date(), errorCode: null, errorMessage: null, updatedAt: new Date() })
          .where(and(eq(sideEffectOperations.id, operation.id), or(eq(sideEffectOperations.status, 'prepared'), eq(sideEffectOperations.status, 'retry_wait'))));
        if (!acquired[0].affectedRows) return;
      } else {
        await this.operations.mark(operation.id, { status: 'executing', attemptCount: operation.attemptCount + 1, startedAt: operation.startedAt ?? new Date(), errorCode: null, errorMessage: null });
      }
      // Last authorization barrier before invoking the provider. The target
      // credential is pinned when the operation is prepared; any rotation or
      // revocation fails closed instead of silently authorizing a new token.
      if (terminalProof) await this.terminalGuard.assertExecutionCurrent(operation.userId, execution!.planId, terminalProof);
      const finalChecked = await this.guard.assertUsable(operation.userId, operation.connectionId, operation.capabilityKey,
        targetAuthorizationFence(operation.requestSnapshotJson, terminalAction) ?? undefined);
      if (finalChecked.connectorKey !== connectorKey) throw new ExecutionRuntimeError('CREDENTIAL_INVALID', 'Target connector changed before dispatch');
      credentialRef = finalChecked.credentialRef;
      credentialVersion = finalChecked.credentialVersion;
      credentialExpiresAt = finalChecked.credentialExpiresAt;
      this.telemetry.increment('connector.calls', 1, { connectorKey, capability: operation.capabilityKey ?? 'unknown', operation: 'execute' });
      dispatchStarted = true;
      const result = await this.telemetry.runWithContext({ connectorKey, requestId: rebuilt.requestId }, () => connector.execute?.({
        capability: operation.capabilityKey!,
        input: { context: { ...rebuilt.triggerPayload, ...handoffTargetContext(rebuilt.actionConfig) }, config: rebuilt.actionConfig },
        requestId: rebuilt.requestId,
        idempotencyKey: operation.idempotencyKey,
        providerIdempotencyKey: operation.providerIdempotencyKey ?? undefined,
        operationId: operation.providerOperationId ?? undefined,
        userId: operation.userId,
        connectionId: operation.connectionId ?? undefined,
        connectorKey,
        credentials: {
          ref: credentialRef ?? undefined,
          version: credentialVersion ?? undefined,
          expiresAt: credentialExpiresAt?.toISOString() ?? null,
        },
      }));
      if (!result) throw new ExecutionRuntimeError('ACTION_RUNTIME_NOT_IMPLEMENTED', 'Connector does not implement execute');
      if (!result.ok) {
        // Provider 明确拒绝：已知失败，不自动盲重试（§13）。
        this.telemetry.increment('connector.provider_5xx', 1, { connectorKey, capability: operation.capabilityKey ?? 'unknown', errorCode: 'PROVIDER_REJECTED' });
        await this.failOperation(operation, message, 'PROVIDER_REJECTED', 'Provider rejected the side effect operation');
        return;
      }
      await this.circuits.recordSuccess(connectorKey);
      this.telemetry.increment('connector.success', 1, { connectorKey, capability: operation.capabilityKey ?? 'unknown', operation: 'execute' });
      this.telemetry.histogram('connector.duration', Date.now() - startedAt, { connectorKey, capability: operation.capabilityKey ?? 'unknown', operation: 'execute' });
      this.telemetry.histogram('outbox.dispatch_duration', Date.now() - startedAt, { connectorKey, capability: operation.capabilityKey ?? 'unknown' });
      await this.succeedOperation(operation, message, result.data, rebuilt.executionId);
    } catch (error) {
      const connectorError = error instanceof ConnectorError ? error : null;
      if (connectorError?.category === 'RATE_LIMITED' && connectorError.retryAfterMs && operation.connectionId) {
        await this.rateLimits.honorRetryAfter(connectorKeyForMetrics, operation.connectionId, connectorError.retryAfterMs);
      }
      if (connectorError && ['TIMEOUT', 'PROVIDER_UNAVAILABLE'].includes(connectorError.category) && connectorError.code !== 'CIRCUIT_OPEN') {
        await this.circuits.recordFailure(connectorKeyForMetrics);
      }
      const mapped = asRuntimeError(error);
      // 审批后权限/连接/凭证变化 → 受控失败，绝不无限重试（§53-55）。
      if (BLOCKING_CODES.has(mapped.code)) {
        if (operation.status === 'executing') {
          await this.unknownOutcome(operation, message, new ExecutionRuntimeError('OUTCOME_UNKNOWN', 'Dispatch recovery cannot confirm the prior effect'), payload.executionId);
          return;
        }
        this.telemetry.increment('connector.auth_failure', 1, { errorCode: mapped.code, connectorKey: connectorKeyForMetrics, capability: operation.capabilityKey ?? 'unknown' });
        await this.failOperation(operation, message, mapped.code, this.sanitizer.sanitizeText(mapped));
        return;
      }
      // §14：请求发送后结果未知（timeout/ambiguous）与发送前失败必须区分。
      const ambiguous = ['TIMEOUT', 'NETWORK_ERROR', 'CONNECTOR_TEMPORARY_ERROR', 'INTERNAL_EXECUTION_ERROR'].includes(mapped.code);
      if (ambiguous && !dispatchStarted) {
        // Integrity/approval checks failed before any provider call: this is a known blocked action, not an unknown side effect.
        await this.failOperation(operation, message, mapped.code, this.sanitizer.sanitizeText(mapped));
        return;
      }
      // §43：retrySafety=unsafe 的 Provider 不自动盲重试模糊失败。
      const contractUnsafe = contract?.retrySafety === 'unsafe';
      if (ambiguous && (contractUnsafe || message.attemptCount + 1 >= MAX_OUTBOX_ATTEMPTS)) {
        this.telemetry.increment('outbox.outcome_unknown', 1, { errorCode: mapped.code });
        await this.unknownOutcome(operation, message, mapped, payload.executionId);
        return;
      }
      if (ambiguous) {
        this.telemetry.increment(mapped.code === 'TIMEOUT' ? 'connector.timeout' : 'outbox.retry_wait', mapped.code === 'TIMEOUT' ? 1 : 1, mapped.code === 'TIMEOUT'
          ? { errorCode: mapped.code, connectorKey: connectorKeyForMetrics, capability: operation.capabilityKey ?? 'unknown' }
          : { errorCode: mapped.code });
        const nextAttemptAt = new Date(Date.now() + Math.min(this.rateLimits.backoffMs(message.attemptCount + 1, connectorError?.retryAfterMs), RETRY_MAX_MS));
        await this.operations.mark(operation.id, { status: 'retry_wait', errorCode: mapped.code, errorMessage: this.sanitizer.sanitizeText(mapped) });
        await this.outbox.markRetryWait(message.id, mapped.code, this.sanitizer.sanitizeText(mapped), nextAttemptAt);
        await this.audit.append({ actorType: 'outbox_worker', actorUserId: null, action: 'SIDE_EFFECT_DISPATCH_RETRY', resourceType: 'side_effect_operation', resourceId: operation.id, userId: operation.userId, executionId: operation.executionId, executionStepId: operation.executionStepId, sideEffectOperationId: operation.id, outboxMessageId: message.id, correlationId: operation.correlationId, causationId: operation.id, after: { attempt: message.attemptCount + 1, nextAttemptAt: nextAttemptAt.toISOString() }, source: 'outbox_worker', result: 'unknown', reasonCode: mapped.code });
        return;
      }
      // 已知安全失败（发送前失败）：同 key 重试至上限后 dead。
      if (message.attemptCount + 1 >= MAX_OUTBOX_ATTEMPTS) {
        this.telemetry.increment('outbox.dead', 1, { reason: mapped.code });
        await this.deadLetter(operation, message, mapped, payload.executionId);
        return;
      }
      this.telemetry.increment(mapped.code === 'RATE_LIMIT' || mapped.code === 'RATE_LIMITED' ? 'connector.rate_limit' : 'outbox.retry_wait', 1, mapped.code === 'RATE_LIMIT' || mapped.code === 'RATE_LIMITED'
        ? { errorCode: mapped.code, connectorKey: connectorKeyForMetrics, capability: operation.capabilityKey ?? 'unknown' }
        : { errorCode: mapped.code });
      const nextAttemptAt = new Date(Date.now() + Math.min(this.rateLimits.backoffMs(message.attemptCount + 1, connectorError?.retryAfterMs), RETRY_MAX_MS));
      await this.operations.mark(operation.id, { status: 'retry_wait', errorCode: mapped.code, errorMessage: this.sanitizer.sanitizeText(mapped) });
      await this.outbox.markRetryWait(message.id, mapped.code, this.sanitizer.sanitizeText(mapped), nextAttemptAt);
    }
  }

  private async cancelOperation(operation: typeof sideEffectOperations.$inferSelect, message: typeof outboxMessages.$inferSelect, code: string, executionId: string) {
    const now = new Date();
    await this.db.transaction(async (tx) => {
      await this.operations.mark(operation.id, { status: 'cancelled', errorCode: code, errorMessage: 'Cancelled before external dispatch', finishedAt: now }, tx);
      await this.stepStates.transition(operation.executionStepId, 'cancelled', { dispatchStatus: 'cancelled', errorCode: code, errorMessage: 'Cancelled before external dispatch', finishedAt: now }, tx);
      await tx.update(outboxMessages).set({ status: 'cancelled', lockedBy: null, lockExpiresAt: null, lastErrorCode: code, lastErrorMessage: 'Cancelled before external dispatch', updatedAt: now }).where(eq(outboxMessages.id, message.id));
      await this.audit.append({ actorType: 'outbox_worker', actorUserId: null, action: 'SIDE_EFFECT_CANCELLED', resourceType: 'side_effect_operation', resourceId: operation.id, userId: operation.userId, executionId, executionStepId: operation.executionStepId, sideEffectOperationId: operation.id, outboxMessageId: message.id, correlationId: operation.correlationId, causationId: operation.id, source: 'outbox_worker', result: 'blocked', reasonCode: code });
    });
    await this.events.append(executionId, 'side_effect_cancelled', { operationId: operation.id }, operation.executionStepId);
    const steps = await this.db.select({ status: executionSteps.status }).from(executionSteps).where(eq(executionSteps.executionId, executionId));
    const succeeded = steps.filter((step) => step.status === 'succeeded').length;
    await this.states.transition(executionId, succeeded > 0 ? 'partially_succeeded' : 'cancelled', { resultCode: 'CANCELLED_BEFORE_DISPATCH', resultSummary: 'Execution cancelled before external dispatch', finishedAt: now, workerToken: null, heartbeatAt: null, leaseExpiresAt: null });
    await this.queue.removeExecutionJob(executionId).catch(() => undefined);
  }

  private async succeedOperation(operation: typeof sideEffectOperations.$inferSelect, message: typeof outboxMessages.$inferSelect, data: Record<string, unknown>, executionId: string) {
    const now = new Date();
    const providerOperationId = String(data.providerOperationId ?? data.id ?? data.postId ?? data.orderId ?? data.messageId ?? null) || null;
    const resultHash = this.operations.hashResult(data);
    // §52：operation succeeded + step succeeded + outbox published + audit 同一 DB 事务。
    const accepted = await this.db.transaction(async (tx) => {
      const live = (await tx.select().from(sideEffectOperations).where(eq(sideEffectOperations.id, operation.id)).limit(1).for('update'))[0];
      if (live?.status === 'outcome_unknown') {
        await this.verification.recordResponse(operation, true, data, 'late-provider-response', tx);
        return false;
      }
      if (!live || ['succeeded', 'failed', 'cancelled'].includes(live.status)) return false;
      await this.operations.mark(operation.id, { status: 'succeeded', resultSnapshotJson: this.sanitizer.sanitize(data), resultHash, providerOperationId, finishedAt: now }, tx);
      await this.verification.recordResponse(operation, true, data, 'dispatch-succeeded', tx);
      await this.stepStates.transition(operation.executionStepId, 'succeeded', { dispatchStatus: 'succeeded', outputSnapshotJson: this.sanitizer.sanitize(data), finishedAt: now }, tx);
      await tx.update(outboxMessages).set({ status: 'published', publishedAt: now, lockedBy: null, lockExpiresAt: null, updatedAt: now }).where(eq(outboxMessages.id, message.id));
      await this.audit.append({ actorType: 'outbox_worker', actorUserId: null, action: 'SIDE_EFFECT_SUCCEEDED', resourceType: 'side_effect_operation', resourceId: operation.id, userId: operation.userId, executionId, executionStepId: operation.executionStepId, sideEffectOperationId: operation.id, outboxMessageId: message.id, correlationId: operation.correlationId, causationId: operation.id, after: { providerOperationId, resultHash }, changeSummary: 'Side effect succeeded', source: 'outbox_worker', result: 'success' }, tx);
      await this.usage.record({
        userId: operation.userId,
        usageType: 'connector.operation',
        quantity: 1,
        unit: 'operation',
        provider: message.destination,
        resourceType: 'side_effect_operation',
        resourceId: operation.id,
        executionId,
        sideEffectOperationId: operation.id,
        usageIdentity: 'connector.operation:side-effect:' + operation.id,
        billable: true,
      }, tx);
      return true;
    });
    if (!accepted) return;
    await this.events.append(executionId, 'side_effect_succeeded', { operationId: operation.id, providerOperationId }, operation.executionStepId);
    await this.resumeExecution(operation.userId, executionId);
  }

  private async failOperation(operation: typeof sideEffectOperations.$inferSelect, message: typeof outboxMessages.$inferSelect, code: string, text: string) {
    const now = new Date();
    const accepted = await this.db.transaction(async (tx) => {
      const live = (await tx.select().from(sideEffectOperations).where(eq(sideEffectOperations.id, operation.id)).limit(1).for('update'))[0];
      if (live?.status === 'outcome_unknown') {
        await this.verification.recordResponse(operation, false, { reasonCode: code }, 'late-provider-failure', tx);
        return false;
      }
      if (!live || ['succeeded', 'failed', 'cancelled'].includes(live.status)) return false;
      await this.operations.mark(operation.id, { status: 'failed', errorCode: code, errorMessage: text.slice(0, 1000), finishedAt: now }, tx);
      await this.verification.recordResponse(operation, false, { reasonCode: code }, 'dispatch-failed', tx);
      await this.stepStates.transition(operation.executionStepId, 'failed', { dispatchStatus: 'failed', errorCode: code, errorMessage: text.slice(0, 1000), finishedAt: now }, tx);
      await tx.update(outboxMessages).set({ status: 'dead', lockedBy: null, lockExpiresAt: null, lastErrorCode: code, lastErrorMessage: text.slice(0, 1000), updatedAt: now }).where(eq(outboxMessages.id, message.id));
      await this.audit.append({ actorType: 'outbox_worker', actorUserId: null, action: 'SIDE_EFFECT_FAILED', resourceType: 'side_effect_operation', resourceId: operation.id, userId: operation.userId, executionId: operation.executionId, executionStepId: operation.executionStepId, sideEffectOperationId: operation.id, outboxMessageId: message.id, correlationId: operation.correlationId, causationId: operation.id, source: 'outbox_worker', result: 'failure', reasonCode: code }, tx);
      return true;
    });
    if (!accepted) return;
    await this.events.append(operation.executionId, 'side_effect_failed', { operationId: operation.id, errorCode: code }, operation.executionStepId);
    await this.finalizeExecution(operation.userId, operation.executionId);
  }

  private async unknownOutcome(operation: typeof sideEffectOperations.$inferSelect, message: typeof outboxMessages.$inferSelect, error: ExecutionRuntimeError, executionId: string) {
    const now = new Date();
    // §50：无 Idempotency / 无 Lookup 的 Provider 在请求可能已到达时 → outcome_unknown，禁止盲 Retry。
    const accepted = await this.db.transaction(async (tx) => {
      const live = (await tx.select().from(sideEffectOperations).where(eq(sideEffectOperations.id, operation.id)).limit(1).for('update'))[0];
      // A stale lease holder cannot overwrite a terminal outcome committed by another worker.
      if (!live || ['succeeded', 'failed', 'cancelled', 'outcome_unknown'].includes(live.status)) return false;
      await this.operations.mark(operation.id, { status: 'outcome_unknown', errorCode: error.code, errorMessage: this.sanitizer.sanitizeText(error), finishedAt: now }, tx);
      await this.verification.openUnknown(operation, error.code, tx);
      await this.stepStates.transition(operation.executionStepId, 'failed', { dispatchStatus: 'outcome_unknown', errorCode: error.code, errorMessage: '操作结果未知，为避免重复已停止自动重试', finishedAt: now }, tx);
      await tx.update(outboxMessages).set({ status: 'dead', lockedBy: null, lockExpiresAt: null, lastErrorCode: error.code, lastErrorMessage: this.sanitizer.sanitizeText(error), updatedAt: now }).where(eq(outboxMessages.id, message.id));
      await this.audit.append({ actorType: 'outbox_worker', actorUserId: null, action: 'SIDE_EFFECT_OUTCOME_UNKNOWN', resourceType: 'side_effect_operation', resourceId: operation.id, userId: operation.userId, executionId, executionStepId: operation.executionStepId, sideEffectOperationId: operation.id, outboxMessageId: message.id, correlationId: operation.correlationId, causationId: operation.id, source: 'outbox_worker', result: 'unknown', reasonCode: error.code, changeSummary: 'Ambiguous outcome; automatic retry stopped' }, tx);
      return true;
    });
    if (!accepted) return;
    await this.notifications.emit({ userId: operation.userId, executionId, executionStepId: operation.executionStepId, priority: 'P0', eventType: 'side_effect_outcome_unknown', dedupeKey: `outcome-unknown:${operation.id}`, title: '操作结果待确认', body: '这一步已向外部服务发出请求，但暂时无法确认最终结果。为了避免重复操作，系统已停止自动重试，需要人工处理。', actionRequired: true });
    await this.events.append(executionId, 'side_effect_outcome_unknown', { operationId: operation.id, errorCode: error.code }, operation.executionStepId);
    await this.finalizeExecution(operation.userId, executionId, 'OUTCOME_UNKNOWN');
  }

  private async deadLetter(operation: typeof sideEffectOperations.$inferSelect, message: typeof outboxMessages.$inferSelect, error: ExecutionRuntimeError, executionId: string) {
    const now = new Date();
    await this.db.transaction(async (tx) => {
      await this.operations.mark(operation.id, { status: 'failed', errorCode: error.code, errorMessage: this.sanitizer.sanitizeText(error), finishedAt: now }, tx);
      await this.stepStates.transition(operation.executionStepId, 'failed', { dispatchStatus: 'failed', errorCode: error.code, errorMessage: this.sanitizer.sanitizeText(error), finishedAt: now }, tx);
      await tx.update(outboxMessages).set({ status: 'dead', lockedBy: null, lockExpiresAt: null, lastErrorCode: error.code, lastErrorMessage: this.sanitizer.sanitizeText(error), updatedAt: now }).where(eq(outboxMessages.id, message.id));
      await this.audit.append({ actorType: 'outbox_worker', actorUserId: null, action: 'SIDE_EFFECT_DEAD_LETTER', resourceType: 'side_effect_operation', resourceId: operation.id, userId: operation.userId, executionId, executionStepId: operation.executionStepId, sideEffectOperationId: operation.id, outboxMessageId: message.id, correlationId: operation.correlationId, causationId: operation.id, source: 'outbox_worker', result: 'failure', reasonCode: error.code }, tx);
    });
    await this.notifications.emit({ userId: operation.userId, executionId, executionStepId: operation.executionStepId, priority: 'P1', eventType: 'side_effect_dead_letter', dedupeKey: `dead-letter:${operation.id}`, title: '外部动作连续失败', body: '外部操作多次尝试仍未成功，系统已停止重试，需要人工处理。', actionRequired: true });
    await this.events.append(executionId, 'side_effect_dead_letter', { operationId: operation.id, errorCode: error.code }, operation.executionStepId);
    await this.finalizeExecution(operation.userId, executionId, error.code);
  }

  // 外部动作成功后，推进 Execution：仍有剩余步骤则 resume 队列，否则直接聚合终态。
  private async resumeExecution(userId: string, executionId: string) {
    const steps = await this.db.select({ status: executionSteps.status }).from(executionSteps).where(eq(executionSteps.executionId, executionId));
    const aggregate = this.resultResolver.resolve(steps);
    if (aggregate === 'succeeded' || aggregate === 'partially_succeeded') {
      await this.finalizeExecution(userId, executionId);
      return;
    }
    await this.states.transition(executionId, 'queued', { queuedAt: new Date() });
    await this.queue.addExecution(executionId, this.policy.current);
  }

  private async finalizeExecution(userId: string, executionId: string, errorCode?: string) {
    const steps = await this.db.select({ status: executionSteps.status }).from(executionSteps).where(eq(executionSteps.executionId, executionId));
    const aggregate = this.resultResolver.resolve(steps);
    const succeededCount = steps.filter((step) => step.status === 'succeeded').length;
    const terminal = errorCode ? (succeededCount > 0 ? 'partially_succeeded' : 'failed') : aggregate;
    await this.states.transition(executionId, terminal, {
      resultCode: errorCode ?? (terminal === 'succeeded' ? 'EXECUTION_COMPLETED' : 'EXECUTION_PARTIALLY_COMPLETED'),
      resultSummary: errorCode ? 'Execution ended after an external side effect could not be confirmed' : terminal === 'succeeded' ? 'All actions completed successfully' : 'Execution completed with skipped or failed steps',
      errorCode: errorCode ?? null,
      errorMessage: errorCode ? '需要人工处理' : null,
      finishedAt: new Date(), workerToken: null, heartbeatAt: null, leaseExpiresAt: null,
    });
    await this.queue.removeExecutionJob(executionId).catch(() => undefined);
    void userId;
  }
}
